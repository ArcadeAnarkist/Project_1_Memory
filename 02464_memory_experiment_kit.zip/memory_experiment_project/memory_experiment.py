
"""
02464 Human Memory Mini Project
Automated experiment runner.

Designed for macOS + VS Code. Uses only the Python standard library.
Audio presentation uses the macOS `say` command. Serial recall is visual by default,
because the lecture notes describe phonological-confusion and articulatory-suppression
effects using visually presented letters.

Outputs:
  data/<participant>_trials.csv
  data/<participant>_items.csv

Run:
  python memory_experiment.py
"""

from __future__ import annotations
import csv
import os
import random
import re
import subprocess
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import simpledialog, messagebox

# -----------------------------
# CONFIGURATION
# -----------------------------

SEED = None
random.seed(SEED)

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)

# Avoid I/L/O because they are easy to confuse with 1/0 when typed.
LETTER_POOL = list("ABCDEFGHJKMNPQRSTUVWXYZ")

FREE_REPS = 5
FREE_N = 16

SERIAL_REPS = 5
SERIAL_N = 12

# More efficient direct test of memory span.
CAPACITY_LENGTHS = [4, 5, 6, 7, 8, 9]
CAPACITY_REPS_PER_LENGTH = 2

# Chunking: same number of letters in both conditions.
CHUNK_WORDS = [
    "CAT", "DOG", "SUN", "CAR", "MAP", "BED", "CUP", "HAT",
    "RED", "BOX", "PEN", "BUS", "KEY", "LEG", "ARM", "SEA"
]
CHUNK_REPS = 3

# Free recall presentation mode chosen by your group.
FREE_MODE = "audio"

# Serial recall should be visual if you want clean articulatory-suppression/error results.
SERIAL_MODE = "visual"

# Seconds between item onsets.
SLOW_INTERVAL = 3.0
FAST_INTERVAL = 1.0

# Pause manipulation.
UNFILLED_DELAY_SECONDS = 60

# Working-memory distractor duration.
WM_TASK_SECONDS = 30

# Visual display duration within each item interval.
VISUAL_ON_SECONDS = 0.7

# -----------------------------
# HELPERS
# -----------------------------

def clean_participant_id(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", s.strip())
    return s or "anonymous"

def random_letters(n: int) -> list[str]:
    """Unique letters within a trial to make free-recall scoring unambiguous."""
    if n > len(LETTER_POOL):
        raise ValueError("n is larger than LETTER_POOL")
    return random.sample(LETTER_POOL, n)

def normalize_letters(text: str) -> list[str]:
    """Accept 'A B C', 'ABC', 'A,B,C', etc."""
    return [c for c in text.upper() if c in LETTER_POOL]

def multiset_free_recall_score(sequence: list[str], response: list[str]):
    """Safe even if duplicates are introduced later."""
    seq_counts = Counter(sequence)
    resp_counts = Counter(response)
    correct = sum(min(seq_counts[k], resp_counts[k]) for k in seq_counts)
    return correct, correct / len(sequence)

def split_regions(n: int):
    """
    Divide serial positions into start/middle/end as evenly as possible.
    Returns dict position_index -> region.
    """
    third = n // 3
    rem = n % 3
    sizes = [third, third, third]
    for i in range(rem):
        sizes[i] += 1

    labels = []
    for name, size in zip(["start", "middle", "end"], sizes):
        labels.extend([name] * size)
    return labels

def now_iso():
    return datetime.now().isoformat(timespec="seconds")

def append_csv(path: Path, row: dict):
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(row.keys()))
        if not exists:
            w.writeheader()
        w.writerow(row)

# -----------------------------
# GUI
# -----------------------------

class MemoryExperiment:
    def __init__(self, root: tk.Tk, participant: str):
        self.root = root
        self.participant = participant
        self.trials_path = DATA_DIR / f"{participant}_trials.csv"
        self.items_path = DATA_DIR / f"{participant}_items.csv"

        self.root.title("02464 Human Memory Experiment")
        self.root.geometry("1000x700")
        self.root.configure(bg="white")

        self.label = tk.Label(
            root, text="", font=("Helvetica", 56, "bold"),
            bg="white", fg="black", wraplength=900, justify="center"
        )
        self.label.pack(expand=True)

        self.info = tk.Label(
            root, text="", font=("Helvetica", 18),
            bg="white", fg="black", wraplength=900, justify="center"
        )
        self.info.pack(pady=20)

        self.tap_count = 0
        self.root.bind("<space>", self._record_tap)
        self.root.update()

    def _record_tap(self, event=None):
        self.tap_count += 1

    def show_text(self, text: str, size=56):
        self.label.config(text=text, font=("Helvetica", size, "bold"))
        self.root.update()

    def show_info(self, text: str):
        self.info.config(text=text)
        self.root.update()

    def clear(self):
        self.label.config(text="")
        self.info.config(text="")
        self.root.update()

    def wait(self, seconds: float, message: str | None = None):
        start = time.perf_counter()
        while True:
            elapsed = time.perf_counter() - start
            remaining = max(0, seconds - elapsed)
            if message:
                self.show_text(f"{message}\n\n{remaining:0.0f} s", 36)
            self.root.update()
            if remaining <= 0:
                break
            time.sleep(0.05)

    def speak(self, item: str):
        """
        macOS audio. `say` is launched asynchronously so the item interval
        is controlled by our timer rather than voice duration.
        """
        try:
            subprocess.Popen(
                ["say", "-r", "320", item],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except FileNotFoundError:
            # Cross-platform fallback.
            self.show_text(item)

    def present_items(
        self,
        items: list[str],
        mode: str,
        interval: float,
        instruction: str = "",
        grouped: bool = False,
        finger_tapping: bool = False,
        articulatory_suppression: bool = False,
    ):
        self.tap_count = 0

        if finger_tapping:
            instruction += "\nTap SPACE repeatedly during presentation."
        if articulatory_suppression:
            instruction += "\nSay 'TAH-DAH-TAH-DAH...' continuously and out loud."

        if instruction:
            self.show_text(instruction, 28)
            self.wait(3)

        for item in items:
            onset = time.perf_counter()

            if mode == "audio":
                self.show_text("+", 40)
                self.speak(item)
            elif mode == "visual":
                self.show_text(item, 72 if len(item) <= 3 else 44)
            else:
                raise ValueError("mode must be 'audio' or 'visual'")

            while time.perf_counter() - onset < min(VISUAL_ON_SECONDS, interval):
                self.root.update()
                time.sleep(0.02)

            if mode == "visual":
                self.show_text("+", 40)

            while time.perf_counter() - onset < interval:
                self.root.update()
                time.sleep(0.02)

        self.clear()
        return self.tap_count

    def get_response(self, prompt: str) -> str:
        self.clear()
        response = simpledialog.askstring("Recall", prompt, parent=self.root)
        return response or ""

    def working_memory_task(self, seconds=WM_TASK_SECONDS):
        """
        Standardised filled delay: multiplication questions.
        This occupies working memory and logs performance.
        """
        self.show_text("Working-memory task", 36)
        self.show_info("Answer as many multiplication questions as you can.")
        self.wait(2)
        start = time.perf_counter()
        n_answered = 0
        n_correct = 0

        while time.perf_counter() - start < seconds:
            a = random.choice([3, 4, 6, 7, 8, 9])
            b = random.randint(2, 12)
            remaining = max(0, seconds - (time.perf_counter() - start))
            ans = simpledialog.askstring(
                "Working-memory task",
                f"{a} × {b} = ?\n\nAbout {remaining:0.0f} s remaining",
                parent=self.root
            )
            if ans is None:
                break
            n_answered += 1
            try:
                if int(ans.strip()) == a * b:
                    n_correct += 1
            except ValueError:
                pass

        return n_answered, n_correct

    def log_trial(
        self,
        experiment: str,
        condition: str,
        trial: int,
        mode: str,
        sequence: list[str],
        response: list[str],
        interval: float,
        delay_seconds: float = 0,
        wm_n=0,
        wm_correct=0,
        tap_count=0,
        chunk_label="",
    ):
        n = len(sequence)
        serial_correct = sum(
            1 for i, x in enumerate(sequence)
            if i < len(response) and response[i] == x
        )
        free_correct, free_accuracy = multiset_free_recall_score(sequence, response)

        # Region-level free recall.
        regions = split_regions(n)
        region_scores = {}
        for region in ["start", "middle", "end"]:
            idx = [i for i, r in enumerate(regions) if r == region]
            region_scores[region] = sum(sequence[i] in response for i in idx) / len(idx)

        trial_row = {
            "timestamp": now_iso(),
            "participant": self.participant,
            "experiment": experiment,
            "condition": condition,
            "trial": trial,
            "mode": mode,
            "n_items": n,
            "interval_s": interval,
            "delay_s": delay_seconds,
            "sequence": " ".join(sequence),
            "response": " ".join(response),
            "free_correct_n": free_correct,
            "free_accuracy": round(free_accuracy, 6),
            "serial_correct_n": serial_correct,
            "serial_accuracy": round(serial_correct / n, 6),
            "start_accuracy": round(region_scores["start"], 6),
            "middle_accuracy": round(region_scores["middle"], 6),
            "end_accuracy": round(region_scores["end"], 6),
            "primacy_index": round(region_scores["start"] - region_scores["middle"], 6),
            "recency_index": round(region_scores["end"] - region_scores["middle"], 6),
            "wm_questions": wm_n,
            "wm_correct": wm_correct,
            "tap_count": tap_count,
            "chunk_label": chunk_label,
        }
        append_csv(self.trials_path, trial_row)

        response_counter = Counter(response)
        for pos, item in enumerate(sequence):
            # For free recall this is membership; sequences are unique by default.
            recalled_anywhere = int(response_counter[item] > 0)
            response_here = response[pos] if pos < len(response) else ""
            item_row = {
                "timestamp": trial_row["timestamp"],
                "participant": self.participant,
                "experiment": experiment,
                "condition": condition,
                "trial": trial,
                "mode": mode,
                "n_items": n,
                "serial_position": pos + 1,
                "region": regions[pos],
                "presented_item": item,
                "response_at_position": response_here,
                "free_recalled": recalled_anywhere,
                "serial_correct": int(response_here == item),
                "substitution": response_here if response_here and response_here != item else "",
                "interval_s": interval,
                "delay_s": delay_seconds,
                "chunk_label": chunk_label,
            }
            append_csv(self.items_path, item_row)

    # -----------------------------
    # FREE RECALL
    # -----------------------------

    def run_free_condition(self, condition: str, interval: float, reps=FREE_REPS,
                           delay=0, working_memory=False):
        for t in range(1, reps + 1):
            seq = random_letters(FREE_N)
            self.show_text(f"Free recall: {condition}\nTrial {t}/{reps}", 32)
            self.show_info("Remember as many letters as possible. Order does NOT matter.")
            self.wait(3)

            self.present_items(seq, FREE_MODE, interval)

            wm_n = wm_correct = 0
            if working_memory:
                wm_n, wm_correct = self.working_memory_task(WM_TASK_SECONDS)
            elif delay > 0:
                self.wait(delay, "Wait before recall")

            raw = self.get_response(
                "Type every letter you remember.\nOrder does not matter.\nExample: A J K R S"
            )
            resp = normalize_letters(raw)

            self.log_trial(
                "free_recall", condition, t, FREE_MODE, seq, resp,
                interval, delay_seconds=delay,
                wm_n=wm_n, wm_correct=wm_correct
            )

    # -----------------------------
    # SERIAL RECALL
    # -----------------------------

    def run_serial_condition(self, condition: str, reps=SERIAL_REPS,
                             finger_tapping=False, suppression=False):
        for t in range(1, reps + 1):
            seq = random_letters(SERIAL_N)
            self.show_text(f"Serial recall: {condition}\nTrial {t}/{reps}", 32)
            self.show_info("Remember the exact sequence and order.")
            self.wait(3)

            taps = self.present_items(
                seq, SERIAL_MODE, SLOW_INTERVAL,
                finger_tapping=finger_tapping,
                articulatory_suppression=suppression
            )

            raw = self.get_response(
                "Type the letters in the SAME ORDER.\nExample: A J K R S"
            )
            resp = normalize_letters(raw)

            self.log_trial(
                "serial_recall", condition, t, SERIAL_MODE, seq, resp,
                SLOW_INTERVAL, tap_count=taps
            )

    def run_capacity(self):
        trial = 0
        conditions = []
        for n in CAPACITY_LENGTHS:
            conditions += [n] * CAPACITY_REPS_PER_LENGTH
        random.shuffle(conditions)

        for n in conditions:
            trial += 1
            seq = random_letters(n)
            self.show_text(f"Memory span\n{n} letters", 34)
            self.show_info("Remember the exact sequence and order.")
            self.wait(2)

            self.present_items(seq, SERIAL_MODE, SLOW_INTERVAL)
            raw = self.get_response("Type the letters in the SAME ORDER.")
            resp = normalize_letters(raw)

            self.log_trial(
                "serial_recall", f"capacity_n{n}", trial, SERIAL_MODE,
                seq, resp, SLOW_INTERVAL
            )

    def chunk_pair(self):
        words = random.sample(CHUNK_WORDS, 4)
        meaningful = list("".join(words))

        fake_chunks = []
        for w in words:
            letters = list(w)
            # Shuffle until it is not the same word.
            while True:
                random.shuffle(letters)
                candidate = "".join(letters)
                if candidate != w:
                    fake_chunks.append(candidate)
                    break
        fake = list("".join(fake_chunks))
        return words, fake_chunks, meaningful, fake

    def run_chunking(self):
        trial_id = 0
        for rep in range(1, CHUNK_REPS + 1):
            words, fake_chunks, meaningful_letters, fake_letters = self.chunk_pair()
            pair = [
                ("meaningful_chunks", words, meaningful_letters),
                ("scrambled_chunks", fake_chunks, fake_letters),
            ]
            random.shuffle(pair)

            for condition, chunks, letter_sequence in pair:
                trial_id += 1
                self.show_text(f"Chunking: {condition.replace('_',' ')}", 32)
                self.show_info("Remember all 12 letters in order.")
                self.wait(2)

                # Show 4 chunks, one every 3 s. Response is still scored as 12 letters.
                self.present_items(chunks, SERIAL_MODE, SLOW_INTERVAL)

                raw = self.get_response(
                    "Type all 12 letters in the SAME ORDER.\nYou may omit spaces."
                )
                resp = normalize_letters(raw)

                self.log_trial(
                    "serial_recall", condition, trial_id, SERIAL_MODE,
                    letter_sequence, resp, SLOW_INTERVAL,
                    chunk_label=" | ".join(chunks)
                )

    # -----------------------------
    # MENUS
    # -----------------------------

    def run_free_all(self):
        conditions = [
            ("baseline", SLOW_INTERVAL, 0, False),
            ("unfilled_delay", SLOW_INTERVAL, UNFILLED_DELAY_SECONDS, False),
            ("fast_rate", FAST_INTERVAL, 0, False),
            ("working_memory", SLOW_INTERVAL, 0, True),
        ]
        # Randomise condition order to reduce systematic fatigue/order effects.
        random.shuffle(conditions)
        for c, interval, delay, wm in conditions:
            self.run_free_condition(c, interval, FREE_REPS, delay, wm)

    def run_serial_all(self):
        # Capacity directly measures the ~7-item limit.
        self.run_capacity()

        conditions = [
            ("baseline_visual", False, False),
            ("finger_tapping", True, False),
            ("articulatory_suppression", False, True),
        ]
        random.shuffle(conditions)
        for c, tap, sup in conditions:
            self.run_serial_condition(c, SERIAL_REPS, tap, sup)

        self.run_chunking()

    def run_everything(self):
        blocks = [self.run_free_all, self.run_serial_all]
        random.shuffle(blocks)
        for block in blocks:
            block()
        messagebox.showinfo(
            "Done",
            f"Experiment complete.\n\nSaved:\n{self.trials_path}\n{self.items_path}"
        )

def main():
    root = tk.Tk()
    root.withdraw()
    participant = simpledialog.askstring(
        "Participant ID",
        "Enter an anonymous participant ID (e.g. P01):",
        parent=root
    )
    if not participant:
        root.destroy()
        return

    participant = clean_participant_id(participant)
    root.deiconify()
    app = MemoryExperiment(root, participant)

    app.show_text("02464 Human Memory Experiment", 38)
    app.show_info(
        "Close other apps and use headphones for audio blocks.\n"
        "For serial recall, stimuli are visual by design."
    )
    app.wait(4)

    choice = simpledialog.askstring(
        "Choose block",
        "Type:\n"
        "ALL = run everything\n"
        "FREE = free recall only\n"
        "SERIAL = serial recall only\n"
        "CAPACITY = memory-span block only\n"
        "CHUNK = chunking block only",
        parent=root
    )
    choice = (choice or "").strip().upper()

    if choice == "ALL":
        app.run_everything()
    elif choice == "FREE":
        app.run_free_all()
    elif choice == "SERIAL":
        app.run_serial_all()
    elif choice == "CAPACITY":
        app.run_capacity()
    elif choice == "CHUNK":
        app.run_chunking()
    else:
        messagebox.showwarning("Cancelled", "No valid block selected.")

    root.destroy()

if __name__ == "__main__":
    main()
