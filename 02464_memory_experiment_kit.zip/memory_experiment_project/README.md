
# 02464 Human Memory Mini Project – experiment kit

This folder contains:

- `memory_experiment.py` — runs the experiment and automatically stores CSV data.
- `memory_analysis.ipynb` — pools participants, plots the effects, and computes bootstrap 95% confidence intervals.
- `data/` — automatically created when the experiment runs.

## Run in VS Code

Open this folder in VS Code, then in a terminal:

```bash
python memory_experiment.py
```

No package install is needed for the experiment runner itself. It uses `tkinter` and, on macOS, the built-in `say` command for audio.

For the analysis notebook, select a Python environment with:

```bash
python -m pip install numpy pandas matplotlib scipy ipykernel
```

## Design choices built into the code

### Free recall
- 16 unique random letters per trial.
- Baseline: 3 s/item, immediate recall.
- Unfilled delay: 60 s before recall.
- Fast rate: 1 s/item.
- Working-memory interference: 30 s of multiplication questions.
- 5 repetitions per condition.
- Primary measures:
  - primacy = start proportion recalled − middle proportion recalled
  - recency = end proportion recalled − middle proportion recalled

### Serial recall
The serial-recall blocks are visual by default. This is intentional: if articulatory suppression is performed while the memory stimuli are auditory, poorer performance could simply come from masking/hearing interference. Visual presentation makes the phonological-loop prediction cleaner.

- Capacity block: lengths 4–9, two trials per length.
- Baseline visual: 12 letters.
- Finger tapping: same visual baseline + repeated SPACE tapping.
- Articulatory suppression: same visual baseline + repeated “TAH-DAH…”.
- Chunking: four familiar 3-letter words vs matched scrambled 3-letter chunks.

### Data
Two files are saved per participant:

1. `<ID>_trials.csv`
2. `<ID>_items.csv`

The item-level file is the one you will mainly use for serial-position curves and error analysis.
